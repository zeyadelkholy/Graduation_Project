// import 'package:flutter/material.dart';
// import 'package:graduation_project/layout/draweBody.dart';
// import 'package:graduation_project/screens/edit_profile.dart';
// import 'package:graduation_project/screens/favourite_Rent.dart';
// import 'package:graduation_project/screens/get_started.dart';
// import 'package:graduation_project/screens/homeScreen.dart';
// import 'package:graduation_project/screens/profile.dart';
// import 'package:slide_drawer/slide_drawer.dart';
//
//
// class SliderDrawer extends StatefulWidget {
//   const SliderDrawer({Key? key}) : super(key: key);
//
//   @override
//   _SliderDrawerState createState() => _SliderDrawerState();
// }
//
// class _SliderDrawerState extends State<SliderDrawer> {
//   @override
//   Widget build(BuildContext context) {
//     return SlideDrawer(
//       items: [MenuItem('Edit Post' ,icon: Icons.person),on],
//       backgroundColor: Colors.deepPurple[300],
//       child: HomeScreen(),);
//   }
// }

