abstract class LayoutStates{}

class LayoutInitialStates extends LayoutStates{}

class LayoutSuccessStates extends LayoutStates{}

