import 'package:graduation_project/models/postsModel.dart';


const DUMMY_MY_POSTS=const[
  'images/download.jpg',
  'images/photourl.jpg',
  'images/download.jpg',
  'images/photourl.jpg',
  'images/photourl.jpg',
  'images/download.jpg',
  'images/download.jpg',
  'images/download.jpg',
];

List<PostModel> DUMMY_DATA = [
  PostModel(
    id: 1,
    name: 'Mona samy',
    date: '',
    ImgUrl: 'images/green.jpg',
    title: 'Green Dress',
    price: 250,
    size: 'L',
    type: '',
    description:
    "Simple gold dress with an extension and hand embroidery and connected belt in the same colour. ps. the dress' shoes are available.",
    width: '',
    gender: 'Female',
    height: '',
  ),
  PostModel(
    id: 2,
    name: 'username2',
    date: '',
    ImgUrl: 'images/white.jpg',
    title: 'White Dress',
    price: 180,
    size: 'L',
    gender: 'Female',
    type: '',
    description:
    "Simple gold dress with an extension and hand embroidery and connected belt in the same colour. ps. the dress' shoes are available.",
    width: '60',
    height: '160',
  ),
  PostModel(
    id: 3,
    name: 'username3',
    date: '155 h',
    ImgUrl: 'images/suit.jpg',
    title: 'Black Suit',
    price: 300,
    gender: 'Male',
    size: 'xL',
    type: 'Grey Suit',
    description:
    "Simple gold dress with an extension and hand embroidery and connected belt in the same colour. ps. the dress' shoes are available.",
    width: '',
    height: '',
  ),
  PostModel(
    id: 4,
    name: 'username4',
    date: '',
    ImgUrl: 'images/silver.jpg',
    title: 'Silver Dress',
    price: 300,
    gender: 'Female',
    type: '',
    size: 'L',
    description:
    "Simple gold dress with an extension and hand embroidery and connected belt in the same colour. ps. the dress' shoes are available.",
    width: '',
    height: '',
  ),
  PostModel(
    id: 5,
    name: 'username5',
    date: '',
    ImgUrl: 'images/suite.jpg',
    title: 'Gray Suit',
    price: 500,
    gender: 'Male',
    type: '',
    size: 'M',
    description:
    "Simple gold dress with an extension and hand embroidery and connected belt in the same colour. ps. the dress' shoes are available.",
    width: '',
    height: '',
  ),
  PostModel(
    id: 6,
    name: 'username6',
    date: '',
    ImgUrl: 'images/mint.jpg',
    title: 'Mint Dress',
    price: 150,
    gender: 'Male',
    size: 'L',
    type: '',
    description:
    "Simple gold dress with an extension and hand embroidery and connected belt in the same colour. ps. the dress' shoes are available.",
    width: '',
    height: '',
  ),

];
